import { Outlet } from "react-router-dom";
import CollegeSidebar from "./CollegeSidebar";
import CollegeTopbar from "./CollegeTopbar";
import AIChatbot from "../AIChatbot";

export default function CollegeLayout() {
  return (
    <div className="min-h-screen bg-slate-50">
      <CollegeSidebar />

      <div className="ml-64 min-w-0">
        <CollegeTopbar />

        <main className="mx-auto max-w-[1400px] p-4 md:p-5">
          <Outlet />
        </main>
      </div>

      <AIChatbot />
    </div>
  );
}