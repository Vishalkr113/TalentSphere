import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  User,
  ClipboardCheck,
  BarChart3,
  ScanSearch,
  FileText,
  Target,
  Compass,
  Map,
  Code2,
  MessageSquare,
  Briefcase,
  GraduationCap,
  Trophy,
  Settings,
  LogOut,
  FileCheck2,
} from "lucide-react";

import { useAuth } from "../../contexts/AuthContext";

const items = [
  ["Dashboard", LayoutDashboard, "dashboard"],
  ["My Profile", User, "profile"],
  ["Assessment", ClipboardCheck, "assessment"],
  ["Assessment Reports", BarChart3, "assessment-reports"],
  ["Skill Gap Analysis", Target, "skill-gap"],
  ["Career Guidance", Compass, "career-guidance"],
  ["Learning Roadmap", Map, "learning-roadmap"],
  ["Resume Builder", FileText, "resume-builder"],
  ["Resume & ATS", ScanSearch, "resume-analyzer"],
  ["Coding / Skill Practice", Code2, "practice"],
  ["Mock Interview", MessageSquare, "mock-interview"],
  ["Placement Readiness", GraduationCap, "placement-readiness"],
  ["Placement Tracker", Briefcase, "placement-tracker"],
  ["Achievements", Trophy, "achievements"],
  ["Final Career Report", FileCheck2, "final-report"],
  ["Settings", Settings, "settings"],
] as const;

export default function CollegeSidebar() {
  const { logout } = useAuth();

  return (
    <aside className="fixed left-0 top-0 z-40 flex h-screen w-64 flex-col border-r bg-white">
      <div className="border-b p-5">
        <h1 className="text-xl font-bold text-cyan-600">TalentSphere</h1>
        <p className="text-xs text-slate-500">College Student Portal</p>
      </div>

      <nav className="flex-1 overflow-y-auto p-3">
        <ul className="space-y-1">
          {items.map(([title, Icon, path]) => (
            <li key={title}>
              <NavLink
                to={`/college-student/${path}`}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium ${
                    isActive
                      ? "bg-cyan-600 text-white"
                      : "text-slate-600 hover:bg-slate-100"
                  }`
                }
              >
                <Icon size={18} />
                {title}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="border-t p-3">
        <button
          onClick={() => {
            logout();
            window.location.href = "/";
          }}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 px-4 py-2.5 font-semibold text-white"
        >
          <LogOut size={17} />
          Logout
        </button>
      </div>
    </aside>
  );
}