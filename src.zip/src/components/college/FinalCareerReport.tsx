import React from "react";
import {
    User,
    FileText,
    BarChart3,
    Target,
    Code2,
    MessageSquare,
    Briefcase,
    Trophy,
    Brain,
    CheckCircle,
} from "lucide-react";

import {
    FinalCareerReport as Report,
    calculateOverallScore,
} from "../../services/college/finalCareerReportService";

export default function FinalCareerReport() {
    const report: Report = {
        profileCompletion: 90,
        resumeScore: 82,
        atsScore: 80,
        assessmentScore: 76,
        codingScore: 74,
        interviewScore: 78,
        placementScore: 84,
        achievementScore: 88,
        overallScore: 0,
    };

    report.overallScore = calculateOverallScore(report);

    return (
        <div className="p-8 space-y-8">
            {/* Header */}
            <div>
                <h1 className="text-3xl font-bold text-slate-800">
                    Final Career Report
                </h1>

                <p className="mt-2 text-slate-500">
                    Complete summary of your college journey.
                </p>
            </div>

            {/* Overall Score */}
            <div className="rounded-3xl bg-gradient-to-r from-cyan-600 to-blue-600 p-8 text-white shadow-lg">
                <h2 className="text-xl font-semibold">
                    Overall Career Readiness
                </h2>

                <div className="mt-4 text-6xl font-bold">
                    {report.overallScore}%
                </div>

                <p className="mt-3 text-cyan-100">
                    Combined performance calculated from Profile, Resume,
                    ATS, Assessment, Coding Practice, Mock Interview,
                    Placement Readiness and Achievements.
                </p>
            </div>

            {/* Student Summary */}

            <div className="rounded-3xl border bg-white p-8 shadow-sm">

                <h2 className="mb-6 text-2xl font-bold text-slate-800">
                    Student Summary
                </h2>

                <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">

                    <SummaryItem
                        title="Student Name"
                        value="Vishal Kumar"
                    />

                    <SummaryItem
                        title="Degree"
                        value="B.Tech"
                    />

                    <SummaryItem
                        title="Branch"
                        value="Computer Science"
                    />

                    <SummaryItem
                        title="Semester"
                        value="6th Semester"
                    />

                    <SummaryItem
                        title="CGPA"
                        value="7.80"
                    />

                    <SummaryItem
                        title="Career Goal"
                        value="Frontend Developer"
                    />

                </div>

            </div>

            {/* Score Cards */}
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
                <ScoreCard title="Profile" score={report.profileCompletion} />
                <ScoreCard title="Resume" score={report.resumeScore} />
                <ScoreCard title="ATS" score={report.atsScore} />
                <ScoreCard title="Assessment" score={report.assessmentScore} />
                <ScoreCard title="Coding" score={report.codingScore} />
                <ScoreCard title="Interview" score={report.interviewScore} />
                <ScoreCard title="Placement" score={report.placementScore} />
                <ScoreCard title="Achievements" score={report.achievementScore} />
            </div>
            {/* Career Performance Summary */}

            <div className="rounded-3xl border bg-white p-8 shadow-sm">

                <h2 className="mb-6 text-2xl font-bold text-slate-800">
                    Career Performance Summary
                </h2>

                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">

                    <PerformanceCard
                        title="Resume Score"
                        value={`${report.resumeScore}%`}
                        status="Good"
                    />

                    <PerformanceCard
                        title="ATS Score"
                        value={`${report.atsScore}%`}
                        status="Good"
                    />

                    <PerformanceCard
                        title="Assessment"
                        value={`${report.assessmentScore}%`}
                        status="Average"
                    />

                    <PerformanceCard
                        title="Coding"
                        value={`${report.codingScore}%`}
                        status="Needs Improvement"
                    />

                    <PerformanceCard
                        title="Interview"
                        value={`${report.interviewScore}%`}
                        status="Good"
                    />

                    <PerformanceCard
                        title="Placement"
                        value={`${report.placementScore}%`}
                        status="Ready"
                    />

                    <PerformanceCard
                        title="Achievements"
                        value={`${report.achievementScore}%`}
                        status="Excellent"
                    />

                    <PerformanceCard
                        title="Overall"
                        value={`${report.overallScore}%`}
                        status="Career Ready"
                    />

                </div>

            </div>

            {/* Resume Summary */}

            <div className="rounded-3xl border bg-white p-8 shadow-sm">

                <h2 className="mb-6 text-2xl font-bold">
                    Resume Summary
                </h2>

                <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">

                    <ScoreCard
                        title="Resume Score"
                        score={report.resumeScore}
                    />

                    <ScoreCard
                        title="ATS Score"
                        score={report.atsScore}
                    />

                    <ScoreCard
                        title="Projects"
                        score={4}
                    />

                    <ScoreCard
                        title="Skills"
                        score={12}
                    />

                </div>
                <div className="rounded-3xl border bg-white p-8 shadow-sm mt-8">

                    <h2 className="mb-6 text-2xl font-bold">
                        Assessment Summary
                    </h2>

                    <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">

                        <ScoreCard
                            title="Assessment"
                            score={report.assessmentScore}
                        />

                        <ScoreCard
                            title="Coding"
                            score={report.codingScore}
                        />

                        <ScoreCard
                            title="Interview"
                            score={report.interviewScore}
                        />

                        <ScoreCard
                            title="Placement"
                            score={report.placementScore}
                        />

                    </div>
                    <div className="rounded-3xl border bg-white p-8 shadow-sm mt-8">

                        <h2 className="mb-6 text-2xl font-bold">
                            Final Verdict
                        </h2>

                        <div className="rounded-xl bg-green-50 border border-green-200 p-6">

                            <h3 className="text-2xl font-bold text-green-700">
                                Placement Ready
                            </h3>

                            <p className="mt-3 text-slate-600">

                                Based on your profile, assessment, resume,
                                ATS score and coding performance,
                                you are ready for entry-level software
                                engineering opportunities.

                            </p>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
}

function ScoreCard({
    title,
    score,
}: {
    title: string;
    score: number;
}) {
    return (
        <div className="rounded-2xl border bg-white p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-500">
                {title}
            </h3>

            <div className="mt-3 text-3xl font-bold text-cyan-600">
                {score}%
            </div>

            <div className="mt-4 h-2 rounded-full bg-slate-200">
                <div
                    className="h-2 rounded-full bg-cyan-600"
                    style={{ width: `${score}%` }}
                />
            </div>
        </div>
    );
}

function ReportCard({
    icon,
    title,
}: {
    icon: React.ReactNode;
    title: string;
}) {
    return (
        <div className="rounded-2xl border bg-white p-6 shadow-sm hover:shadow-md transition">

            <div className="mb-4 text-cyan-600">
                {icon}
            </div>

            <h2 className="text-lg font-semibold text-slate-800">
                {title}
            </h2>

            <p className="mt-2 text-sm text-slate-500">
                This section will automatically generate insights from the
                corresponding completed module.
            </p>

        </div>
    );
}

function SummaryItem({
    title,
    value
}: {
    title: string;
    value: string;
}) {

    return (

        <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">

            <p className="text-sm text-slate-500">
                {title}
            </p>

            <h3 className="mt-2 text-lg font-semibold text-slate-800">
                {value}
            </h3>

        </div>

    );
}
function PerformanceCard({
    title,
    value,
    status,
}: {
    title: string;
    value: string;
    status: string;
}) {
    return (
        <div className="rounded-2xl border bg-slate-50 p-5">

            <p className="text-sm text-slate-500">
                {title}
            </p>

            <h3 className="mt-2 text-3xl font-bold text-cyan-600">
                {value}
            </h3>

            <span className="mt-4 inline-block rounded-full bg-cyan-100 px-3 py-1 text-xs font-semibold text-cyan-700">
                {status}
            </span>

        </div>
    );
}